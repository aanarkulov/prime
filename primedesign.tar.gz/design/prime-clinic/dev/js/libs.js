
@@include('../libs/jquery/jquery.js')
@@include('../libs/uikit3/uikit.min.js')
@@include('../libs/uikit3/uikit-icons.min.js')
@@include('../libs/slick/slick.min.js')
@@include('../libs/jquery.lazy/jquery.lazy.min.js')
@@include('../libs/jquery.lazy/jquery.lazy.plugins.min.js')
@@include('../libs/jquery.mask/jquery.mask.js')
@@include('../libs/lightgallery/lightgallery-all.js')

@@include('../libs/selectize/js/standalone/selectize.js')