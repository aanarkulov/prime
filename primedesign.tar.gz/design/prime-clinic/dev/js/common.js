
$(document).ready(function () {

  var SliderFor = $('.slider-for');
  var SliderNav = $('.slider-nav');
  var OurDoctorsSlider = $('.our-doctors-slider');
  var NewsAndBlogSlider = $('.news-and-blog-slider');
  var DiagnosticSlider = $('.diagnostic-slider');
  var LazyLoadImage = $('.lazy');
  var Mask = $('.phone_us');
  var SetWidth = parseInt($('.uk-container').css('margin-left').split('px')[0]) + 40;

  if (Mask !== undefined && Mask !== null) {
    Mask.mask('(996) 000-00-00-00');
  }

  if (SliderFor !== undefined && SliderFor !== null) {
    SliderFor.slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      speed: 900,
      asNavFor: '.slider-nav',
      lazyLoad: 'ondemand'
    });
  }
  if (SliderNav !== undefined && SliderNav !== null) {
    SliderNav.slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      asNavFor: '.slider-for',
      arrows: true,
      dots: false,
      speed: 900,
      appendArrows: $(".home-slider"),
      nextArrow: '<span class="arrow-left uk-box-shadow-hover-large" uk-icon="icon: arrow-left" id="arrow-left"></span>',
      prevArrow: '<span class="arrow-right uk-box-shadow-hover-large" uk-icon="icon: arrow-right" id="arrow-right"></span>',
      centerMode: false,
      focusOnSelect: true

    });
  }

  // reinit lazy load

  if (SliderFor !== undefined && SliderFor !== null) {
    SliderFor.on('lazyLoaded', function (event, slick, currentSlide, nextSlide) {
      UIkit.update(event = 'update');
    });
  }

  if (DiagnosticSlider !== undefined && DiagnosticSlider !== null) {
    DiagnosticSlider.on('lazyLoaded', function (event, slick, currentSlide, nextSlide) {
      UIkit.update(event = 'update');
    });
  }

  if (NewsAndBlogSlider !== undefined && NewsAndBlogSlider !== null) {
    NewsAndBlogSlider.on('lazyLoaded', function (event, slick, currentSlide, nextSlide) {
      UIkit.update(event = 'update');
    });
  }

  if (OurDoctorsSlider !== undefined && OurDoctorsSlider !== null) {
    OurDoctorsSlider.slick({
      dots: false,
      infinite: true,
      speed: 900,
      slidesToShow: 3,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      nextArrow: '<span class="arrow-left uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-left" id="arrow-left"></span>',
      prevArrow: '<span class="arrow-right uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-right" id="arrow-right"></span>',
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 960,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 640,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  }

  if (NewsAndBlogSlider !== undefined && NewsAndBlogSlider !== null) {
    NewsAndBlogSlider.slick({
      dots: false,
      infinite: true,
      speed: 900,
      slidesToShow: 3,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      nextArrow: '<span class="arrow-left uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-left" id="arrow-left"></span>',
      prevArrow: '<span class="arrow-right uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-right" id="arrow-right"></span>',
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 960,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 640,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  }

  if (DiagnosticSlider !== undefined && DiagnosticSlider !== null) {
    DiagnosticSlider.slick({
      dots: false,
      infinite: true,
      speed: 900,
      slidesToShow: 3,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      nextArrow: '<span class="arrow-left uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-left" id="arrow-left"></span>',
      prevArrow: '<span class="arrow-right uk-box-shadow-hover-large uk-box-shadow-small" uk-icon="icon: arrow-right" id="arrow-right"></span>',
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 960,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 640,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  }

  if (LazyLoadImage !== undefined && LazyLoadImage !== null) {
    LazyLoadImage.lazy({
      effect: "fadeIn",
      effectTime: 500,
      threshold: 0,
      enableThrottle: true,
      throttle: 250,
      placeholder: "../img/loading.gif"
    });


    LazyLoadImage.load(function () {
      UIkit.update(event = 'update');
    });
  }

  $('.form-search-doctors').selectize({
  });


  $('.text').css({ "padding-left": SetWidth + "px" })
  $('.text').css({ "padding-right": SetWidth + "px" })

  $(window).resize(function () {
    var SetWidth = parseInt($('.uk-container').css('margin-left').split('px')[0]) + 40;
    $('.text').css({ "padding-left": SetWidth + "px" })
    $('.text').css({ "padding-right": SetWidth + "px" })
  })


  $('.radio-label,input[type="radio"]').on('click', function () {
    var tr = $(this).parent().parent();
    if ($(this).closest('input[type="radio"]:checked')) {
      $(tr).addClass('active');
      $(tr).siblings().removeClass('active');
    }
  })
  //   $("input[type='radio']").change(function() {
  //     if(this.checked) {
  //        $('tbody tr').removeClass('line');
  //        $('tbody tr').addClass('line');
  //     }
  //  });

}); // end document.ready



// $(document).ajaxComplete(loadCommon);
//     $(function () { loadCommon(); });

//     function loadCommon() {
//         // Писать common.js скрипты сюда
//     }

